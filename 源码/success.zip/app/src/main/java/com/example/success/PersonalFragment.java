package com.example.success;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class PersonalFragment extends Fragment {//页面 我的
    private View root;
    private TextView user;
    private TextView sex;
    private TextView hobby;
    private ImageView img;
    private TextView menu;
    private String[] replySplit = null;
    private String phone_number;
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 1:
                    AlertDialog.Builder builder  = new AlertDialog.Builder(getContext());
                    builder.setTitle("不存在此菜谱");
                    builder.setPositiveButton("重新输入" ,  null );
                    builder.show();
                    break;
                case 2:
                    String str = (String) msg.obj;
                    Intent intent = new Intent(getContext(), oneMenuActivity.class);
                    intent.putExtra("information",str);
                    startActivity(intent);
                    break;
            }
        }
    };
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_person,container,false);

        user = root.findViewById(R.id.user);
        sex = root.findViewById(R.id.sex);
        hobby = root.findViewById(R.id.hobby);
        img = root.findViewById(R.id.img);

        //登陆
        ImageView button_login = root.findViewById(R.id.login);
        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(getContext(),
                        LoginActivity.class);
                startActivityForResult(intent,1);
            }
        });

        //注册
        ImageView button_register = root.findViewById(R.id.register);
        button_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(getContext(),
                        RegisterActivity.class);
                startActivity(intent);
            }
        });
        //修改个人信息
        ImageView btn_change = root.findViewById(R.id.change);
        btn_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(getContext(),
                        change.class);
                startActivity(intent);
            }
        });
        //修改头像
        ImageView btn_changeImg = root.findViewById(R.id.btn_changeImg);
        btn_changeImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(getContext(),
                        changeImg.class);
                startActivity(intent);
            }
        });
        //我的点赞
        ImageView btn_likes = root.findViewById(R.id.btn_likes);
        btn_likes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(replySplit==null){
                    AlertDialog.Builder builder  = new AlertDialog.Builder(getContext());
                    builder.setTitle("查看失败");
                    builder.setMessage("请先登录，登陆才能查看个人点赞");
                    builder.setPositiveButton("登陆", null);
                    builder.show();
                }
                else {
                    Intent intent = new Intent();
                    intent.setClass(getContext(),
                            LikesActivity.class);
                    intent.putExtra("phone_number",replySplit[1]);
                    startActivity(intent);
                }
            }
        });
        //我的评论
        ImageView btn_comments = root.findViewById(R.id.btn_comments);
        btn_comments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(replySplit==null){
                    AlertDialog.Builder builder  = new AlertDialog.Builder(getContext());
                    builder.setTitle("查看失败");
                    builder.setMessage("请先登录，登陆才能查看个人评论");
                    builder.setPositiveButton("登陆", null);
                    builder.show();
                }
                else {
                    Intent intent = new Intent();
                    intent.setClass(getContext(),
                            CommentsActivity.class);
                    intent.putExtra("phone_number",replySplit[1]);
                    startActivity(intent);
                }
            }
        });
        //搜索菜谱
        menu = root.findViewById(R.id.menu);
        ImageView search = root.findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    @Override
                    public void run() {
                        //使用URL和URLConnection方法进行网络连接
                        try {
                            URL url = new URL(ConfigUtil.SERVER_ADDR+"AndroidSearchOneMenu");
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            //设置网络请求方式为post

                            conn.setRequestMethod("POST");
                            //获取网络输出流
                            OutputStream out = conn.getOutputStream();
                            //后取代发送的字符串
                            String str = menu.getText().toString().trim();
                            out.write(str.getBytes());
                            //必须获取输入流保障服务端客户端建立连接
                            conn.getInputStream();
                            //接受回应
                            //获取网络输入流
                            InputStream in = conn.getInputStream();
                            //使用字符流读取
                            BufferedReader reader = new BufferedReader(
                                    new InputStreamReader(in, "utf-8"));

                            String reply = reader.readLine();
                            if(reply.equals("false")){
                                Message msg = new Message();
                                //设置Message对象的参数
                                msg.what = 1;
                                //发送Message
                                handler.sendMessage(msg);
                            }
                            else {
                                Message msg = new Message();
                                //设置Message对象的参数
                                msg.what = 2;
                                msg.obj = reply;
                                //发送Message
                                handler.sendMessage(msg);
                            }
                            //关闭流
                            reader.close();
                            in.close();
                            out.close();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                }.start();
            }
        });
        return root;
    }

    //个人信息
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1&&resultCode==2){
            String reply = data.getStringExtra("information" );
            Log.e("回应信息",reply);
            if(reply!=null){
                replySplit = reply.split("&&&");

                Log.e("回应信息姓名",replySplit[3]);

                user.setText(replySplit[3]);

                sex.setText("性别:"+replySplit[4]);

                StringBuffer hobbyShow = new StringBuffer();

                if(replySplit[5].equals("1"))
                    hobbyShow.append("川菜    ");
                if(replySplit[6].equals("1"))
                    hobbyShow.append("鲁菜    ");
                if(replySplit[7].equals("1"))
                    hobbyShow.append("豫菜");

                hobby.setText("爱好:  "+hobbyShow);

                if(replySplit[8].equals("erha"))
                    img.setImageDrawable(getResources().getDrawable(R.drawable.dog2));
                else if(replySplit[8].equals("keji"))
                    img.setImageDrawable(getResources().getDrawable(R.drawable.dog3));
                else if(replySplit[8].equals("tuzi"))
                    img.setImageDrawable(getResources().getDrawable(R.drawable.notdog));
            }

        }
    }
}
