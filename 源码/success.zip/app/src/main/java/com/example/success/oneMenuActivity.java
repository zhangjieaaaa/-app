package com.example.success;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class oneMenuActivity extends AppCompatActivity {
    private TextView like;
    private EditText something;
    private TextView saySomething1;
    private String position;
    private String[] userNames;
    private String[] comments;
    private String[] split;
    private String str = "";
    private int likes = 0;
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 1:
                    like =  findViewById(R.id.like);
                    like.setText("点赞量："+likes);
                    break;
                case 2:
                    like.setText("点赞量："+(++likes));
                    AlertDialog.Builder builder  = new AlertDialog.Builder(oneMenuActivity.this);
                    builder.setTitle("点赞成功");
                    builder.setPositiveButton("继续浏览" ,  null );
                    builder.show();
                    break;
                case 3:
                    AlertDialog.Builder builder1  = new AlertDialog.Builder(oneMenuActivity.this);
                    builder1.setTitle("失败");
                    builder1.setMessage("请先登录，登陆后才能点赞或评论");
                    builder1.setPositiveButton("登陆", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    });
                    builder1.show();
                    break;
                case 4:
                    String name = (String) msg.obj;
                    saySomething1.setText(saySomething1.getText().toString()+"\r\n"+ name + ":" + something.getText().toString().trim());
                    AlertDialog.Builder builder4  = new AlertDialog.Builder(oneMenuActivity.this);
                    builder4.setTitle("评论成功");
                    builder4.setPositiveButton("继续浏览" ,  null );
                    builder4.show();
                    break;
                case 5:
                    AlertDialog.Builder builder5  = new AlertDialog.Builder(oneMenuActivity.this);
                    builder5.setTitle("评论失败");
                    builder5.setPositiveButton("请在输入框输入内容才能评论" ,  null );
                    builder5.show();
                    break;
                case 6:
                    if(userNames!=null){
                        for(int i=0;i<userNames.length;++i){
                            str = str + userNames[i] + ":" + comments[i] + "\r\n";
                        }
                        saySomething1.setText(str);
                    }
                    break;
                case 7:
                    Bitmap bitmap = (Bitmap) msg.obj;
                    ImageView img = findViewById(R.id.img);
                    img.setImageBitmap(bitmap);
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one_menu);

        Intent intent =getIntent();
        String information = intent.getStringExtra("information");
        split = information.split("&&&");

        downloadImg();//下载图片
        TextView introduce = findViewById(R.id.introduce);//名字
        introduce.setText(split[1]);

        TextView type = findViewById(R.id.type);
        type.setText(split[2]);

        TextView material = findViewById(R.id.material);
        material.setText(split[3]);

        TextView steps = findViewById(R.id.steps);
        steps.setText(split[4]);

        TextView like = findViewById(R.id.like);
        like.setText("点赞量：" + split[5]);

        menuInformation();
        comment();//初始化评论
        //存储点赞信息
        ImageView btn_like = findViewById(R.id.btn_like);
        btn_like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    @Override
                    public void run() {
                        //使用URL和URLConnection方法进行网络连接
                        try {
                            URL url = new URL(ConfigUtil.SERVER_ADDR+"AndroidLikeServlet");
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            //设置网络请求方式为post
                            conn.setRequestMethod("POST");
                            //获取网络输出流
                            OutputStream out = conn.getOutputStream();
                            //后取代发送的字符串
                            String str = split[1];
                            out.write(str.getBytes());
                            //必须获取输入流保障服务端客户端建立连接
                            conn.getInputStream();
                            //接受回应
                            //获取网络输入流
                            InputStream in = conn.getInputStream();
                            //使用字符流读取
                            BufferedReader reader = new BufferedReader(
                                    new InputStreamReader(in, "utf-8"));
                            String reply = reader.readLine();
                            Log.e(reply,reply);
                            if(reply.equals("true")){
                                Message msg = new Message();
                                //设置Message对象的参数
                                msg.what = 2;
                                //发送Message
                                handler.sendMessage(msg);
                            }
                            else{
                                Message msg = new Message();
                                //设置Message对象的参数
                                msg.what = 3;
                                //发送Message
                                handler.sendMessage(msg);
                            }
                            //关闭流
                            reader.close();
                            in.close();
                            out.close();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                }.start();
            }
        });






        //  评论  评论  评论
        something = findViewById(R.id.something);
        saySomething1 = findViewById(R.id.say1);
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    @Override
                    public void run() {
                        //使用URL和URLConnection方法进行网络连接
                        try {
                            URL url = new URL(ConfigUtil.SERVER_ADDR+"AndroidCommentServlet");
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            //设置网络请求方式为post
                            conn.setRequestMethod("POST");
                            //获取网络输出流
                            OutputStream out = conn.getOutputStream();
                            //后取代发送的字符串
                            String str = split[1] + "&&&" +something.getText().toString().trim();
                            out.write(str.getBytes());
                            //必须获取输入流保障服务端客户端建立连接
                            conn.getInputStream();

                            out.close();
                            //接受回应
                            //获取网络输入流
                            InputStream in = conn.getInputStream();
                            //使用字符流读取
                            BufferedReader reader = new BufferedReader(
                                    new InputStreamReader(in, "utf-8"));
                            String strReply = reader.readLine();
                            String[] reply = strReply.split("&&&");
                            if(reply[0].equals("true")){
                                Message msg = new Message();
                                //设置Message对象的参数
                                msg.what = 4;
                                msg.obj = reply[1];
                                //发送Message
                                handler.sendMessage(msg);
                            }
                            else if(reply[0].equals("falseNoUser")){
                                Message msg = new Message();
                                //设置Message对象的参数
                                msg.what = 3;
                                //发送Message
                                handler.sendMessage(msg);
                            }
                            else{
                                Message msg = new Message();
                                //设置Message对象的参数
                                msg.what = 5;
                                //发送Message
                                handler.sendMessage(msg);
                            }
                            //关闭流
                            reader.close();
                            in.close();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                }.start();
            }
        });
    }
    private void comment() {//初始化评论
        new Thread(){
            @Override
            public void run() {
                try {
                    //向服务端提交键值对
                    String keyValue = "?name="+split[1]+"";
                    URL url = new URL(ConfigUtil.SERVER_ADDR + "AndroidCommentInitServlet"+keyValue);
                    //获取网络输入流
                    InputStream in = url.openStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in,"utf-8"));
                    //读取数据
                    String str = null;
                    str = reader.readLine();
                    if(str!=null){
                        Log.e("",str);
                        String[] strSplit = str.split("split");
                        userNames = strSplit[0].split("&&&");
                        comments = strSplit[1].split("&&&");
                    }
                    in.close();

                    Message msg = handler.obtainMessage();
                    msg.what=1;
                    handler.sendMessage(msg);

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();

    }


    /*
     **解析传来的字符
     */
    private void menuInformation() {
        new Thread(){
            @Override
            public void run() {
                try {
                    //向服务端提交键值对
                    String keyValue = "?name="+split[1]+"";
                    URL url = new URL(ConfigUtil.SERVER_ADDR + "AndroidOneMenuServlet"+keyValue);
                    //获取网络输入流
                    InputStream in = url.openStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in,"utf-8"));
                    //读取数据
                    String str = reader.readLine();

                    likes = Integer.parseInt(str);
                    System.out.println(likes);
                    in.close();
                    Message msg = handler.obtainMessage();
                    msg.what=6;
                    handler.sendMessage(msg);

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }


    /**
     * 下载服务端图片
     * @param
     */
    private void downloadImg() {
        new Thread(){
            @Override
            public void run() {
                //下载图片
                try {
                    URL url = new URL(ConfigUtil.SERVER_ADDR + split[0]);
                    URLConnection conn = url.openConnection();
                    //获取字节输入流
                    InputStream in = conn.getInputStream();
                    //把输入流解析成一个Bitmap对象
                    Bitmap bitmap = BitmapFactory.decodeStream(in);
                    in.close();
                    Message msg = new Message();
                    msg.what=7;
                    msg.obj=bitmap;
                    handler.sendMessage(msg);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();

    }

}
