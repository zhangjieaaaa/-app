package com.example.success;

public class ConfigUtil {
    public static final String SERVER_ADDR = "http://192.168.3.8:8080/BIgBIgBIg/";
}