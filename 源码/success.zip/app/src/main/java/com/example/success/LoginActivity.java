package com.example.success;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Person;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class LoginActivity extends AppCompatActivity {
    private EditText user;
    private EditText password;
    private Button login;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 1://弹出密码错误提示框
                    AlertDialog.Builder builder  = new AlertDialog.Builder(LoginActivity.this);
                    builder.setTitle("验证错误");
                    builder.setMessage("手机号或密码错误");
                    builder.setPositiveButton("重新输入" ,  null );
                    builder.show();
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        user = findViewById(R.id.user);
        password = findViewById(R.id.password);
        login = findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    @Override
                    public void run() {
                        //使用URL和URLConnection方法进行网络连接
                        try {
                            URL url = new URL(ConfigUtil.SERVER_ADDR+"LoginServlet");
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            //设置网络请求方式为post
                            conn.setRequestMethod("POST");
                            //获取网络输出流
                            OutputStream out = conn.getOutputStream();
                            //后取代发送的字符串
                            String str = user.getText().toString().trim()+"&&&"+
                                    password.getText().toString().trim();
                            out.write(str.getBytes());
                            //必须获取输入流保障服务端客户端建立连接
                            conn.getInputStream();
                            //接受回应
                            //获取网络输入流
                            InputStream in = conn.getInputStream();
                            //使用字符流读取
                            BufferedReader reader = new BufferedReader(
                                    new InputStreamReader(in, "utf-8"));
                            //读取字符信息:账号密码是否正确&&&手机号&&&密码&&&昵称&&&性别&&&川菜&&&鲁菜&&&豫菜&&&头像
                            String reply = reader.readLine();
                            String[] replySplit = reply.split("&&&");

                            Log.e(reply,reply);

                            if(replySplit[0].equals("true")){
                                Intent response  = new Intent();
                                response.putExtra("information",reply);
                                setResult(2,response);
                                finish();
                            }

                            if(replySplit[0].equals("false")){
                                Message msg = new Message();
                                //设置Message对象的参数
                                msg.what = 1;
                                //发送Message
                                handler.sendMessage(msg);
                            }
                            //关闭流
                            reader.close();
                            in.close();
                            out.close();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                }.start();
            }
        });
    }
}
