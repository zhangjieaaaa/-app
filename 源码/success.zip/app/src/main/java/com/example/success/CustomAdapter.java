package com.example.success;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends BaseAdapter {
    private Context mContext;
    private List<Things> things = new ArrayList<>();
    private int itemLayoutRes;

    public CustomAdapter(Context mContext, List<Things> things, int itemLayoutRes) {
        this.mContext = mContext;
        this.things = things;
        this.itemLayoutRes = itemLayoutRes;
    }

    @Override
    public int getCount() {
        if(null != things)
            return things.size();
        return 0;
    }

    @Override
    public Object getItem(int position) {
        if(null !=things)
            return things.get(position);
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(R.layout.menu_list,null);

        ImageView img = convertView.findViewById(R.id.img);
        TextView text =  convertView.findViewById(R.id.text);
        TextView type =  convertView.findViewById(R.id.type);
        TextView likes =  convertView.findViewById(R.id.likes);

        img.setImageBitmap( things.get(position).getPhotoId());
        text.setText(things.get(position).getName());
        type.setText(things.get(position).getType());
        likes.setText(things.get(position).getLikes());








        return convertView;
    }
}