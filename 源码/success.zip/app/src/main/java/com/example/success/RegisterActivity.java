package com.example.success;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class RegisterActivity extends AppCompatActivity {
    private EditText user;
    private EditText password;
    private EditText name;
    private EditText sex;
    private Button register;
    private CheckBox box1,box2,box3;
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 0://注册成功提示框
                    AlertDialog.Builder builder  = new AlertDialog.Builder(RegisterActivity.this);
                    builder.setTitle("注册成功");
                    builder.setMessage("快去登陆吧");
                    builder.setPositiveButton("登陆", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    });
                    builder.show();

                    break;
                case 1://弹出注册失败提示框
                    AlertDialog.Builder builder1  = new AlertDialog.Builder(RegisterActivity.this);
                    builder1.setTitle("注册失败");
                    builder1.setMessage("可能你的手机号已经被注册过了，换个手机号试试吧");
                    builder1.setPositiveButton("重新注册" ,  null );
                    builder1.show();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        user = findViewById(R.id.user);
        password = findViewById(R.id.password);
        name = findViewById(R.id.name);
        sex = findViewById(R.id.sex);
        box1 = (CheckBox) findViewById(R.id.chuan);
        box2 = (CheckBox) findViewById(R.id.lu);
        box3 = (CheckBox) findViewById(R.id.yu);
        register = findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    @Override
                    public void run() {
                        //使用URL和URLConnection方法进行网络连接
                        try {
                            URL url = new URL(ConfigUtil.SERVER_ADDR+"RegisterServlet");
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            //设置网络请求方式为post
                            conn.setRequestMethod("POST");
                            //获取网络输出流
                            OutputStream out = conn.getOutputStream();
                            //后取代发送的字符串
                            StringBuffer sb=new StringBuffer();
                            //判断CheckBox是否被选中
                            if(box1.isChecked()){
                                //把被选中的文字添加到StringBuffer中
                                sb.append("&&&");
                                sb.append("1");
                            }
                            else{
                                sb.append("&&&");
                                sb.append("0");
                            }
                            if(box2.isChecked()){
                                //把被选中的文字添加到StringBuffer中
                                sb.append("&&&");
                                sb.append("1");
                            }
                            else{
                                sb.append("&&&");
                                sb.append("0");
                            }
                            if(box3.isChecked()){
                                //把被选中的文字添加到StringBuffer中
                                sb.append("&&&");
                                sb.append("1");
                            }
                            else{
                                sb.append("&&&");
                                sb.append("0");
                            }

                            String str = user.getText().toString().trim()+"&&&"+
                                    password.getText().toString().trim()+"&&&"+
                                    name.getText().toString().trim()+"&&&"+
                                    sex.getText().toString().trim()+sb;
                            Log.e("information",str);
                            out.write(str.getBytes());
                            //必须获取输入流保障服务端客户端建立连接
                            conn.getInputStream();
                            //接受回应
                            //获取网络输入流
                            InputStream in = conn.getInputStream();
                            //使用字符流读取
                            BufferedReader reader = new BufferedReader(
                                    new InputStreamReader(in, "utf-8"));
                            //读取字符信息
                            String reply = reader.readLine();
                            Log.e(reply,reply);
                            if(reply.equals("true")){
                                Log.e("true","true");
                                Message msg = new Message();
                                //设置Message对象的参数
                                msg.what = 0;
                                //发送Message
                                handler.sendMessage(msg);
                            }

                            if(reply.equals("false")){
                                Log.e("false","false");
                                Message msg = new Message();
                                //设置Message对象的参数
                                msg.what = 1;
                                //发送Message
                                handler.sendMessage(msg);
                            }
                            //关闭流
                            reader.close();
                            in.close();
                            out.close();

                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                }.start();
            }
        });


    }
}
