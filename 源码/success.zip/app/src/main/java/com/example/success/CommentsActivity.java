package com.example.success;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class CommentsActivity extends AppCompatActivity {
    private ArrayList<String> list = new ArrayList<String>();
    private String phone_number;
    private String comments[];
    ArrayAdapter adapter;
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 1:
                    list.clear();
                    for(int i = 0;i<comments.length;++i){
                        list.add(comments[i]);
                    }
                    adapter.notifyDataSetChanged();
                    break;
                case 2:
                    AlertDialog.Builder builder  = new AlertDialog.Builder(CommentsActivity.this);
                    builder.setTitle("查看失败");
                    builder.setMessage("请先登录，登陆才能查看个人评论");
                    builder.setPositiveButton("登陆", null);
                    builder.show();
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);
        initMenuList();
    }

    private void initMenuList(){
        Intent intent =getIntent();
        phone_number = intent.getStringExtra("phone_number");
        getComments();

        ListView MenuListView = findViewById(R.id.comments_list);
        adapter = new ArrayAdapter(this,android.R.layout.simple_expandable_list_item_1,list);
        MenuListView.setAdapter(adapter);


        //4.给thingsListView设置item点击事件的监听器 （显示各个菜的做法）
        MenuListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //parent是ListView对象
                //view是点击的item的视图对象
                //position是点击的item的位置，从0开始
                Log.e("点击ListView中position",position + "条");
                Log.e("点击ListView中id",id + "条");

                Intent intent = new Intent(CommentsActivity.this, deleteOneComment.class);
                intent.putExtra("information",comments[position]);

                startActivityForResult(intent,1);
            }
        });
    }

    //刷新页面
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        getComments();
    }

    //评论
    private void getComments() {
        new Thread(){
            @Override
            public void run() {
                try {
                    URL url = new URL(ConfigUtil.SERVER_ADDR+"AndroidGetCommentsServlet");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    //设置网络请求方式为post
                    conn.setRequestMethod("POST");
                    //获取网络输出流
                    OutputStream out = conn.getOutputStream();
                    out.write(phone_number.getBytes());
                    //必须获取输入流保障服务端客户端建立连接
                    conn.getInputStream();
                    //接受回应
                    //获取网络输入流
                    InputStream in = conn.getInputStream();
                    //使用字符流读取
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(in, "utf-8"));
                    String reply = reader.readLine();
                    if(reply==null){
                        //不做事
                    }
                    else if(reply.equals("false")){
                        Message msg = new Message();
                        //设置Message对象的参数
                        msg.what = 2;
                        //发送Message
                        handler.sendMessage(msg);
                    }else{
                        comments = reply.split("&&&");
                        Message msg = new Message();
                        //设置Message对象的参数
                        msg.what = 1;
                        //发送Message
                        handler.sendMessage(msg);
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }



}
