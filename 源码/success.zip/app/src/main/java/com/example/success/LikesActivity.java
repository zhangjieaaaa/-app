package com.example.success;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LikesActivity extends AppCompatActivity {
    private ArrayList<String> list = new ArrayList<String>();
    private String phone_number;
    private String likes[];
    ArrayAdapter adapter;
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 1:
                    list.clear();
                    for(int i = 0;i<likes.length;++i){
                        list.add(likes[i]);
                    }
                    adapter.notifyDataSetChanged();
                    break;
                case 2:
                    AlertDialog.Builder builder  = new AlertDialog.Builder(LikesActivity.this);
                    builder.setTitle("查看失败");
                    builder.setMessage("请先登录，登陆才能查看个人点赞");
                    builder.setPositiveButton("登陆", null);
                    builder.show();
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_likes);
        initMenuList();
    }

    private void initMenuList(){
        Intent intent =getIntent();
        phone_number = intent.getStringExtra("phone_number");

        getLikes();

        ListView MenuListView = findViewById(R.id.likes_list);
        adapter = new ArrayAdapter(this,android.R.layout.simple_expandable_list_item_1,list);
        MenuListView.setAdapter(adapter);

    }


    //点赞
    private void getLikes() {
        new Thread(){
            @Override
            public void run() {
                try {
                    URL url = new URL(ConfigUtil.SERVER_ADDR+"AndroidGetLikesServlet");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    //设置网络请求方式为post
                    conn.setRequestMethod("POST");
                    //获取网络输出流
                    OutputStream out = conn.getOutputStream();
                    out.write(phone_number.getBytes());
                    //必须获取输入流保障服务端客户端建立连接
                    conn.getInputStream();
                    //接受回应
                    //获取网络输入流
                    InputStream in = conn.getInputStream();
                    //使用字符流读取
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(in, "utf-8"));
                    String reply = reader.readLine();
                    if(reply==null){
                       //不做事
                    }
                        else if(reply.equals("false")){
                            Message msg = new Message();
                            //设置Message对象的参数
                            msg.what = 2;
                            //发送Message
                            handler.sendMessage(msg);
                        }else{
                            likes = reply.split("&&&");
                            Message msg = new Message();
                            //设置Message对象的参数
                            msg.what = 1;
                            //发送Message
                            handler.sendMessage(msg);
                        }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

}
