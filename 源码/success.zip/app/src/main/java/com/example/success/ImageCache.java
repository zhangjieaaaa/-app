package com.example.success;

import android.graphics.Bitmap;

import java.util.List;

/**
 * 缓存图片数据
 */
public class ImageCache {
    public static List<Bitmap> bitmaps;
    public static String[] names;
    public static String[] types;
    public static String[] materials;
    public static String[] steps;
    public static String[] likes;
}
