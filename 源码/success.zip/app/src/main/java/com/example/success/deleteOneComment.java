package com.example.success;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class deleteOneComment extends AppCompatActivity {
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 1:
                    Intent response  = new Intent();
                    setResult(2,response);
                    finish();
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_one_comment);

        Intent intent =getIntent();
        final String menuComment = intent.getStringExtra("information");

        Button button = findViewById(R.id.delete);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    @Override
                    public void run() {
                        try {
                            URL url = new URL(ConfigUtil.SERVER_ADDR+"AndroidDeleteOneComment");
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            //设置网络请求方式为post
                            conn.setRequestMethod("POST");
                            //获取网络输出流
                            OutputStream out = conn.getOutputStream();
                            out.write(menuComment.getBytes());
                            //必须获取输入流保障服务端客户端建立连接
                            conn.getInputStream();
                            out.close();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        Message msg = new Message();
                        //设置Message对象的参数
                        msg.what = 1;
                        //发送Message
                        handler.sendMessage(msg);
                    }
                }.start();
            }
        });

    }
}
