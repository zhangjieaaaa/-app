package com.example.success;

import android.graphics.Bitmap;

public class Things {
    private String name;
    private Bitmap photoId;
    private String type;
    private String likes;

    public Things(String name, Bitmap photoId, String type, String likes) {
        this.name = name;
        this.photoId = photoId;
        this.type = type;
        this.likes = likes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Bitmap getPhotoId() {
        return photoId;
    }

    public void setPhotoId(Bitmap photoId) {
        this.photoId = photoId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLikes() {
        return likes;
    }

    public void setLikes(String likes) {
        this.likes = likes;
    }
}

