package com.example.success;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainFragment extends Fragment {
    String[] split;
    String[] imgs;//菜图
    String[] splitName;
    String[] names;//菜名
    String[] splitType;
    String[] type;//类型
    String[] splitMaterial;
    String[] Material;//原料
    String[] splitSteps;
    String[] Steps;//步骤
    String[] likes;//点赞数



    private View root;
    private List<Things> things = new ArrayList<>();
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 1://表示线程下载图片完成
                    //将下载好的图片缓存
                    ImageCache.bitmaps = (List<Bitmap>) msg.obj;
                    break;
                case 2 :
                    ImageCache.types = (String[]) msg.obj;
                    break;
                case 3 :
                    ImageCache.materials = (String[]) msg.obj;
                    break;
                case 4 :
                    ImageCache.steps = (String[]) msg.obj;
                    break;
                case 5 :
                    ImageCache.likes = (String[]) msg.obj;
                    break;
                case 6:
                    ImageCache.names = (String[]) msg.obj;
                    if(ImageCache.names!=null){
                        for(int i=0;i<ImageCache.names.length;i++){
                            Things thing = new Things(ImageCache.names[i],ImageCache.bitmaps.get(i),ImageCache.types[i],ImageCache.likes[i]);
                            things.add(thing);
                        }
                    }
                    root.requestLayout();
            }
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_main,container,false);

        //加载图片和名字
        downLoadImages();
        //图片显示在图片空间中
        //定义item布局文件（自定义）
        //创建Adapter
        CustomAdapter customAdapter = new CustomAdapter(getContext(),things,R.layout.menu_list);
        //绑定Adapter
        ListView thingsListView = root.findViewById(R.id.lv_shop);
        thingsListView.setAdapter(customAdapter);

        //4.给thingsListView设置item点击事件的监听器 （显示各个菜的做法）
        thingsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //parent是ListView对象
                //view是点击的item的视图对象
                //position是点击的item的位置，从0开始
                Log.e("点击ListView中position",position + "条");
                Log.e("点击ListView中id",id + "条");

                Intent intent = new Intent(getContext(), CookieActivity.class);
                intent.putExtra("information",position+"");

                startActivity(intent);

            }
        });

        return root;

    }

    /*
     **下载八个图片
     */
    private void downLoadImages() {
        //判断是否已经缓存图片
        if(null==ImageCache.bitmaps||ImageCache.bitmaps.size()==0){
            new Thread(){
                @Override
                public void run() {
                    System.out.println("第一步");
                    //1接收服务端发送的图片相对路径
                    try {
                        URL url = new URL(ConfigUtil.SERVER_ADDR + "DownSevalImgServlet");
                        //获取网络输入流
                        InputStream in = url.openStream();
                        BufferedReader reader = new BufferedReader(new InputStreamReader(in,"utf-8"));
                        //读取数据
                        String str = reader.readLine();
                        System.out.println(str);
                        in.close();



                        //解析传来的字符串转换为四个字符数组
                        split = str.split("&&&first");//split[0]一次解析，分解图片
                        imgs = split[0].split("&&&");//一次解析，分解图片

                        splitName = split[1].split("&&&second");//二次解析，分解名字
                        names = splitName[0].split("&&&");//二次解析，分解名字

                        splitType = splitName[1].split("&&&third");//二次解析，分解类型
                        type = splitType[0].split("&&&");//二次解析，分解类型

                        splitMaterial = splitType[1].split("&&&fourth");//三次解析，分解原料
                        Material = splitMaterial[0].split("&&&");//三次解析，分解原料

                        splitSteps = splitMaterial[1].split("&&&fifth");//四次解析，分解做法
                        Steps = splitSteps[0].split("&&&");//四次解析，分解做法

                        likes =  splitSteps[1].split("&&&");//五次解析，分解点赞


                        System.out.println(Arrays.asList(imgs));
                        System.out.println(Arrays.asList(names));
                        System.out.println(Arrays.asList(type));
                        System.out.println(Arrays.asList(Material));
                        System.out.println(Arrays.asList(Steps));

                        //3下载图片
                        List<Bitmap> bitmaps = new ArrayList<>();

                        //下载图片
                        for(int i =0;i<imgs.length;++i){
                            System.out.println("正在下载第"+i+"图片");
                            //拼接图片对应的url
                            String imgUrl = ConfigUtil.SERVER_ADDR + imgs[i];
                            System.out.println("正在下载第图片地址"+imgUrl);
                            //使用网络连接下载图片
                            URL url1 = new URL(imgUrl);
                            InputStream in1 = url1.openStream();
                            //讲输入流解析成bitmap对象
                            Bitmap bitmap = BitmapFactory.decodeStream(in1);
                            //将下载好的图片添加到bitmaps集合
                            bitmaps.add(bitmap);
                            in1.close();
                        }
                        in.close();
                        //使用message将下载好的图片列表发送给UI
                        Message msg = handler.obtainMessage();
                        msg.what=1;
                        msg.obj = bitmaps;
                        handler.sendMessage(msg);

                        Message msg2 = handler.obtainMessage();
                        msg2.what=2;
                        msg2.obj = type;
                        handler.sendMessage(msg2);

                        Message msg3 = handler.obtainMessage();
                        msg3.what=3;
                        msg3.obj = Material;
                        handler.sendMessage(msg3);

                        Message msg4 = handler.obtainMessage();
                        msg4.what=4;
                        msg4.obj = Steps;
                        handler.sendMessage(msg4);

                        Message msg5 = handler.obtainMessage();
                        msg5.what=5;
                        msg5.obj = likes;
                        handler.sendMessage(msg5);

                        Message msg6 = handler.obtainMessage();
                        msg6.what=6;
                        msg6.obj = names;
                        handler.sendMessage(msg6);


                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }.start();
        }
        else
            System.out.println("线程下载图片已经完成，无需下载");
    }

}
