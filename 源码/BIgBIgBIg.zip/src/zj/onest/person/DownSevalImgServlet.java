package zj.onest.person;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zj.onest.entitys.Menu;
import zj.onest.services.MenuService;

/**
 * Servlet implementation class DownSevalImgServlet
 */
@WebServlet("/DownSevalImgServlet")
public class DownSevalImgServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DownSevalImgServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		// ����û��Ƿ��Ѿ���¼
		ServletContext context = getServletContext();
		Object user = context.getAttribute("user");
		
		System.out.println(user);
		

		//���ز���ͼƬ
		//�Ѷ��ͼƬ��ַ���͸��ͻ���
		//1��ȡͼƬ��ַ(��ȡվ���Ŀ¼����ȡ��Ŀ¼�µ�imgsĿ¼����ȡimgsĿ¼�µ�����ͼƬ�ļ�)��
		//��ȡվ���Ŀ¼
		String file = getServletContext().getRealPath("/");
		System.out.println(file);
		//2��ȡprintWriter���� 
		PrintWriter writer = response.getWriter();
		
		MenuService menuService = new MenuService();
		List<Menu> menus = menuService.getMenusLikes("select * from menu");
		
		for (Menu menu : menus) {
			writer.write("imgs/"+ menu.getImg()+".jpg" + "&&&");
		}
		
		 writer.write("first");//��һ�ηָ���

		for (Menu menu : menus) {
			writer.write(menu.getName()+"&&&");
		}
		
		writer.write("second");
		
		for (Menu menu : menus) {
			writer.write(menu.getType()+"&&&");
		}
		
		writer.write("third");
		
		for (Menu menu : menus) {
			writer.write(menu.getMaterial()+"&&&");
		}
		
		writer.write("fourth");
		
		for (Menu menu : menus) {
			writer.write(menu.getSteps()+"&&&");
		}
		
		writer.write("fifth");
		for (Menu menu : menus) {
			writer.write(menu.getLikes()+"&&&");
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
