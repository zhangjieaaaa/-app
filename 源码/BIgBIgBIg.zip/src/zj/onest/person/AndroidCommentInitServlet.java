package zj.onest.person;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zj.onest.services.MenuService;
import zj.onest.services.RegisterService;

/**
 * Servlet implementation class AndroidCommentInitServlet
 */
@WebServlet("/AndroidCommentInitServlet")
public class AndroidCommentInitServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AndroidCommentInitServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String str = null;
		//��ȡ�ͻ��˷��͵ļ�ֵ����Ϣ
		String name = request.getParameter("name");
		MenuService menuService = new MenuService();
		str = menuService.oneComments(name);
		if(str!=null) {
			String[] split = str.split("split");
			String[] phoneNumber = split[0].split("&&&");
			String names = "";
			for(int i=0;i<phoneNumber.length;++i) {
				try {
					names = names + new RegisterService().searchUserByuser(phoneNumber[i].toString()) + "&&&";
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			str = names +"split"+ split[1];
			
			//��ͻ��˷����ַ�������
			//��ȡprintWriter����
			PrintWriter writer = response.getWriter();
			//��ͻ��˷����ַ���Ϣ
			writer.write(str);
			
			System.out.println("�Ѿ���ͻ��˷����ַ���Ϣ");

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
