package zj.onest.person;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zj.onest.services.MenuService;
import zj.onest.services.RegisterService;

/**
 * Servlet implementation class AndroidCommentServlet
 */
@WebServlet("/AndroidCommentServlet")
public class AndroidCommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AndroidCommentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");  
		response.setContentType("text/html;charset=utf-8");
		// ����û��Ƿ��Ѿ���¼
		ServletContext context = getServletContext();
		Object user = context.getAttribute("user");
		System.out.println(user);
		
		//ʹ�����ķ�ʽ���ܿͻ��˵�����
		//��ȡ����������
		InputStream in = request.getInputStream();
		BufferedReader reader = new BufferedReader(new InputStreamReader(in,"utf-8"));
		PrintWriter writer = response.getWriter();
		String str = reader.readLine();
				
		String[] aha = null; 
		String menuName =null;
		String comment = null;
		if(str!=null) {
			aha = str.split("&&&");
			menuName = aha[0];
			if(aha.length==2)
				comment = aha[1];
		}
		if(menuName==null||comment==null)
			writer.write("falseComment");
		if(user==null) {
			writer.write("falseNoUser");
		}
		else if(user!=null&&comment!=null){//д�����ݿ�
			String name = null;
			new MenuService().commentsAdd(user.toString(), menuName, comment);
			try {
				name = new RegisterService().searchUserByuser(user.toString());
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			writer.write("true"+"&&&"+name);
		}


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
