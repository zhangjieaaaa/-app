package zj.onest.person;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zj.onest.entitys.Menu;
import zj.onest.services.MenuService;

/**
 * Servlet implementation class AndroidSearchOneMenu
 */
@WebServlet("/AndroidSearchOneMenu")
public class AndroidSearchOneMenu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AndroidSearchOneMenu() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		//ʹ�����ķ�ʽ���ܿͻ��˵�����
		//��ȡ����������
		InputStream in = request.getInputStream();
		BufferedReader reader = new BufferedReader(new InputStreamReader(in,"utf-8"));
		String name = reader.readLine();
		
		MenuService menuService = new MenuService();
		List<Menu> menus = new ArrayList<Menu>();;
		menus = menuService.getMenusLikes("select * from menu where name = '"+name+"'");
		PrintWriter writer = response.getWriter();
		if(menus.size()!=0) {
			Menu menu = menus.get(0);
			writer.write("imgs/"+ menu.getImg()+".jpg" + "&&&");
			writer.write(menu.getName()+"&&&");
			writer.write(menu.getType()+"&&&");
			writer.write(menu.getMaterial()+"&&&");
			writer.write(menu.getSteps()+"&&&");
			writer.write(menu.getLikes()+"&&&");
		}else
			writer.write("false");
			
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
