package zj.onest.person;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zj.onest.services.RegisterService;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * ��½ҳ��
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ���ñ��뷽ʽ
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		//ʹ�����ķ�ʽ���ܿͻ��˵�����
		//��ȡ����������
		InputStream in = request.getInputStream();
		BufferedReader reader = new BufferedReader(new InputStreamReader(in,"utf-8"));
		String str = reader.readLine();
	
		if(str!=null) {
			String[] imgs = str.split("&&&");
			boolean b = new RegisterService().isExistUser(imgs[0],imgs[1]);
			if(b) {
				// ���û�����ServletContext
				getServletContext().setAttribute("user", imgs[0]);

			}

			System.out.println(b);
				try {
					String replyIngformation = new RegisterService().searchUser(imgs[0],imgs[1]);
					
					//��ͻ��˷����ַ�������
					String reply = b+"&&&"+replyIngformation+"";
					System.out.println(reply);
					//��ȡprintWriter����
					PrintWriter writer = response.getWriter();
					//��ͻ��˷����ַ���Ϣ
					writer.write(reply);
					System.out.println("�Ѿ���ͻ��˷����ַ���Ϣ");
	
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
