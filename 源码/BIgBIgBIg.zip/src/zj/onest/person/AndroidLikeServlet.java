package zj.onest.person;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zj.onest.services.MenuService;
import zj.onest.services.RegisterService;

/**
 * Servlet implementation class AndroidLikeServlet
 */
@WebServlet("/AndroidLikeServlet")
public class AndroidLikeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AndroidLikeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		//ʹ�����ķ�ʽ���ܿͻ��˵�����
		//��ȡ����������
		InputStream in = request.getInputStream();
		BufferedReader reader = new BufferedReader(new InputStreamReader(in,"utf-8"));
		String name = reader.readLine();
		String menuName = null;
		if(name!=null) {
			menuName = name;
		}

		// ����û��Ƿ��Ѿ���¼
		ServletContext context = getServletContext();
		Object user = context.getAttribute("user");
		String userName = null;
		System.out.println(user);
		PrintWriter writer = response.getWriter();
		if(user==null) {
			writer.write("false");
		}
		else {
			userName = user.toString();
			writer.write("true");
		}

		if(user!=null&&name!=null) {		
			//����menu��
			MenuService menuService = new MenuService();
			menuService.MenuAddLike(name);
			
			//����like��
			menuService.LikesAddLike(userName, menuName);

		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
