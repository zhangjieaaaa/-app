package zj.onest.person;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zj.onest.entitys.Menu;
import zj.onest.services.MenuService;

/**
 * Servlet implementation class AndroidOneMenuServlet
 */
@WebServlet("/AndroidOneMenuServlet")
public class AndroidOneMenuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AndroidOneMenuServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		// ����û��Ƿ��Ѿ���¼
		ServletContext context = getServletContext();
		Object user = context.getAttribute("user");
		
		System.out.println(user);
		
		
	
		//��ȡ�ͻ��˷��͵ļ�ֵ����Ϣ
		String name = request.getParameter("name");
		System.out.println(name);
		
		// ��ȡ�û���Ϣ
		MenuService menuService = new MenuService();
		
		String likes = menuService.getLikes("select * from menu where name = '"+name+"'");

		// ��������
		//��ͻ��˷����ַ�������
		System.out.println(likes);
		//��ȡprintWriter����
		PrintWriter writer = response.getWriter();
		//��ͻ��˷����ַ���Ϣ
		writer.write(likes);
		System.out.println("�Ѿ���ͻ��˷����ַ���Ϣ");
		
		
		


		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
