package zj.onest.entitys;

public class User {
	private String phone_number;//�ֻ���
	private String password;//�û�����
	private String name;//�ǳ�
	private String img;//ͷ��
	private String sex;//�Ա�
	private int hobby_chuan;//����
	private int hobby_lu;//����
	private int hobby_yu;//����
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getHobby_chuan() {
		return hobby_chuan;
	}
	public void setHobby_chuan(int hobby_chuan) {
		this.hobby_chuan = hobby_chuan;
	}
	public int getHobby_lu() {
		return hobby_lu;
	}
	public void setHobby_lu(int hobby_lu) {
		this.hobby_lu = hobby_lu;
	}
	public int getHobby_yu() {
		return hobby_yu;
	}
	public void setHobby_yu(int hobby_yu) {
		this.hobby_yu = hobby_yu;
	}
	public User(String phone_number, String password, String name, String img, String sex, int hobby_chuan,
			int hobby_lu, int hobby_yu) {
		super();
		this.phone_number = phone_number;
		this.password = password;
		this.name = name;
		this.img = img;
		this.sex = sex;
		this.hobby_chuan = hobby_chuan;
		this.hobby_lu = hobby_lu;
		this.hobby_yu = hobby_yu;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
	
	
}
