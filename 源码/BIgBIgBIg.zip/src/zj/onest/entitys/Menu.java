package zj.onest.entitys;

public class Menu {
	private String id;
	private String name;
	private String type;
	private String img;//ͼƬ��Դ��ַ
	private String material;
	private String steps;
	private int likes;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public int getLikes() {
		return likes;
	}
	public void setLikes(int likes) {
		this.likes = likes;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getSteps() {
		return steps;
	}
	public void setSteps(String steps) {
		this.steps = steps;
	}
	public Menu(String id, String name, String type, String img, String material, String steps) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
		this.img = img;
		this.material = material;
		this.steps = steps;
	}
	public Menu(String id, String name, String type, String img, String material, String steps,int likes) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
		this.img = img;
		this.material = material;
		this.steps = steps;
		this.likes = likes;
	}
	public Menu() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
