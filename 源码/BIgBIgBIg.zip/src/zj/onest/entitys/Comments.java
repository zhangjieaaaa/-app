package zj.onest.entitys;

public class Comments {
	private int id;
	private String phone_number;
	private String menu_name;
	private String comment;

	
	public Comments(int id, String phone_number, String menu_name, String comment) {
		super();
		this.id = id;
		this.phone_number = phone_number;
		this.menu_name = menu_name;
		this.comment = comment;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getPhone_number() {
		return phone_number;
	}


	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}


	public String getMenu_name() {
		return menu_name;
	}


	public void setMenu_name(String menu_name) {
		this.menu_name = menu_name;
	}


	public String getComment() {
		return comment;
	}


	public void setComment(String comment) {
		this.comment = comment;
	}


	public Comments() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
