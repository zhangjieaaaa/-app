package zj.onest.entitys;

public class Administrator {
	private String uName;	//�û���
	private String uPwd;	//�û�����
	
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getuPwd() {
		return uPwd;
	}
	public void setuPwd(String uPwd) {
		this.uPwd = uPwd;
	}
	public Administrator(String uName, String uPwd) {
		super();
		this.uName = uName;
		this.uPwd = uPwd;
	}
	
	public Administrator() {
		super();
	}
	
		
}