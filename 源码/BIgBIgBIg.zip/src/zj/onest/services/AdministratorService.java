package zj.onest.services;

import java.sql.ResultSet;
import java.sql.SQLException;

import zj.onest.entitys.Administrator;
import zj.onest.util.DBUtil;


public class AdministratorService {
	private DBUtil dbUtil;
	
	public AdministratorService() {
		try {
			dbUtil = DBUtil.getInstance();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	/**
	 * �ж��û��Ƿ����
	 * @param user ���жϵ��û�
	 * @return �����򷵻�true�����򷵻�false
	 */
	public boolean isExistUser(Administrator administrator) {
		//��ȡ���жϵ��û���Ϣ
		String uName = administrator.getuName();
		String uPwd = administrator.getuPwd();

		//�����û���Ϣƴ��sql���
		String sql = "select * from administrators_information where user = '" + uName +"' and password = '" + uPwd +"'";
		System.out.println(sql);
		boolean b = false;
		try {
			b = dbUtil.isExist(sql);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return b;
	}
	
	
	
}
