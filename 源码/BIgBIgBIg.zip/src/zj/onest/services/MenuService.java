package zj.onest.services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import zj.onest.entitys.Comments;
import zj.onest.entitys.Likes;
import zj.onest.entitys.Menu;
import zj.onest.entitys.User;
import zj.onest.util.DBUtil;

public class MenuService {
	private List<Menu> menus;
	private List<Comments> comments;
	private List<Likes> likes;
	private DBUtil dbUtil;
	public MenuService() {
		try {
			menus = new ArrayList<Menu>();
			comments = new ArrayList<Comments>();
			likes = new ArrayList<Likes>();
			dbUtil = DBUtil.getInstance();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * ���ݲ�����Ϣ�������
	 */
	private Menu createMenu(String id, String name, String type, String img, String material, String steps) {
		Menu menu = new Menu();

		menu.setId(id);
		menu.setName(name);
		menu.setType(type);
		menu.setImg(img);
		menu.setMaterial(material);
		menu.setSteps(steps);
		return menu;
	}
	private Menu createMenu(String id, String name, String type, String img, String material, String steps,int likes) {
		Menu menu = new Menu();

		menu.setId(id);
		menu.setName(name);
		menu.setType(type);
		menu.setImg(img);
		menu.setMaterial(material);
		menu.setSteps(steps);
		menu.setLikes(likes);
		return menu;
	}
	private Likes createLike(int id,String phone_number, String menu_name) {
		Likes likes = new Likes();
		likes.setId(id);
		likes.setPhone_number(phone_number);
		likes.setMenu_name(menu_name);
		return likes;
	}
	/**
	 * ��ȡ���е�����Ϣ
	 */
	public List<Likes> getLikesHtml(String sql){
		try {
			//��ѯ�����û���Ϣ
			ResultSet rs = dbUtil.queryDate(sql);
			while(rs.next()) {
				String id = rs.getString("id");
				String phone_number = rs.getString("phone_number");
				String menu_name = rs.getString("menu_name");
				Likes like = createLike(Integer.parseInt(id),phone_number, menu_name);
				likes.add(like);
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return likes;
	}
	/**
	 * ����������Ϣ�������
	 */
	private Comments createComments(int id,String phone_number, String menu_name, String comment) {
		Comments comments = new Comments();
		comments.setId(id);
		comments.setPhone_number(phone_number);
		comments.setMenu_name(menu_name);
		comments.setComment(comment);
		return comments;
	}
	/**
	 * ��ȡ����������Ϣ
	 */
	public List<Comments> getComments(String sql){
		try {
			//��ѯ�����û���Ϣ
			ResultSet rs = dbUtil.queryDate(sql);
			while(rs.next()) {
				String id = rs.getString("id");
				String phone_number = rs.getString("phone_number");
				String menu_name = rs.getString("menu_name");
				String comment = rs.getString("comment");
				Comments comment0 = createComments(Integer.parseInt(id),phone_number, menu_name, comment);
				comments.add(comment0);
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return comments;
	}
	/**
	 * ��ȡ���в�����Ϣ
	 */
	public List<Menu> getMenus(String sql){
		try {
			//��ѯ�����û���Ϣ
			ResultSet rs = dbUtil.queryDate(sql);
			while(rs.next()) {
				String id = rs.getString("id");
				String name = rs.getString("name");
				String type = rs.getString("type");
				String img= rs.getString("img");
				String material= rs.getString("material");
				String steps= rs.getString("steps");

				Menu menu = createMenu(id, name, type, img, material,steps);
				menus.add(menu);
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return menus;
	}
	public List<Menu> getMenusLikes(String sql){
		try {
			//��ѯ�����û���Ϣ
			ResultSet rs = dbUtil.queryDate(sql);
			while(rs.next()) {
				String id = rs.getString("id");
				String name = rs.getString("name");
				String type = rs.getString("type");
				String img= rs.getString("img");
				String material= rs.getString("material");
				String steps= rs.getString("steps");
				String likes = rs.getString("likes");

				Menu menu = createMenu(id, name, type, img, material,steps,Integer.parseInt(likes));
				menus.add(menu);
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return menus;
	}
	
	/**
	 * ���ݲ���idɾ������
	 */
	public boolean deleteMenuById(String id) {
		String sql="delete from menu where id='"+id+"'";
		int n=-1;
		try {
			n=dbUtil.addDataToTable(sql);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n>0?true:false;
	}
	
	
	/**
	 * ���Ӳ���
	 */
	public boolean addMenu(Menu menu) {
				
		//��ȡ������Ϣ
		String name=menu.getName();
		String type=menu.getType();
		String img=menu.getImg();
		String material=menu.getMaterial();
		String steps=menu.getSteps();
		
		//ƴ�Ӳ����û���sql���
		String sql="insert into menu(name,type,img,material,steps)"
				+ " values ('"+name +"','"+type+"','"+img+"','"+material+"','"+steps+"')";
		
		System.out.println(sql);
		//��ͼ�����Ϣ�����û�����
		int n = -1;//�洢����ļ�¼��
		try {
			n = dbUtil.addDataToTable(sql);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return n > 0 ? true : false;
			
	}
	
	
	
	
	/**
	 * ����ͼid�޸�ָ������
	 */
	public boolean alterMenuById(String id, String name, String type, String img, String material, String steps) {
		String sql="UPDATE menu SET  name = '"+name+"', type = '"+type+"', img = '"+img+"', material = '"+material+"', steps = '"+steps+"'" + 
				"WHERE id = '"+id+"'";
		int n=-1;
		try {
			n=dbUtil.addDataToTable(sql);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n>0?true:false;
	}
	
	
	
	/**
	 * ��ȡ���׵�����Ϣ
	 */
	public String getLikes(String sql){
		String likes = "0";
		try {
			ResultSet rs = dbUtil.queryDate(sql);
			while(rs.next()) {
				likes= rs.getString("likes");
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return likes;
	}
	
	/**
	 * ���׵��ޣ�����menu��
	 */
	public boolean MenuAddLike(String name) {
		
		String likes = getLikes("select * from menu where name = '"+name+"'");
		
		int addLike = Integer.parseInt(likes)+1;
		
		String sql="UPDATE menu SET likes = '"+addLike+"' "+ 
				"WHERE name = '"+name+"'";
		int n=-1;
		try {
			n=dbUtil.addDataToTable(sql);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n>0?true:false;
	}
	
	/**
	 * ���׵��ޣ�����likes��
	 */
	public boolean LikesAddLike(String phone_number,String menu_name) {
		
		String sql="insert into likes(phone_number,menu_name)"
				+ " values ('"+phone_number +"','"+menu_name+"')";
		int n=-1;
		try {
			n=dbUtil.addDataToTable(sql);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n>0?true:false;
	}
	
	/**
	 * ��ȡ���в��׵�����Ϣ
	 */
	public String onePersongetMenusLikes(String sql){
		String str = "";
		try {
			ResultSet rs = dbUtil.queryDate(sql);
			while(rs.next()) {
				String name = rs.getString("menu_name");
				str = str + name + "&&&";
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return str;
	}
	
	/**
	 * �������ۣ�����comments��
	 */
	public boolean commentsAdd(String phone_number,String menu_name,String comment) {
		
		String sql="insert into comments(phone_number,menu_name,comment)"
				+ " values ('"+phone_number +"','"+menu_name+"','"+comment+"')";
		int n=-1;
		try {
			n=dbUtil.addDataToTable(sql);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n>0?true:false;
	}
	
	/**
	 * ��ȡ���в���������Ϣ
	 */
	public String oneComments(String name) {
		String str = null;
		String Phonenumber = "";
		String something = "";
		String sql="select * from comments where menu_name = '" + name + "'";	
		try {
			ResultSet rs = dbUtil.queryDate(sql);
			while(rs.next()) {
				String phone_number = rs.getString("phone_number");
				String comment = rs.getString("comment");
				Phonenumber = Phonenumber + phone_number+"&&&";
				something = something  + comment + "&&&";
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		if(!Phonenumber.equals(""))
			str = Phonenumber + "split" + something;
		return str;
	}
	
	/**
	 * ��ȡ���˲���������Ϣ
	 */
	public String onePersongetMenusComments(String sql){
		String str = "";
		try {
			ResultSet rs = dbUtil.queryDate(sql);
			while(rs.next()) {
				String menu_name = rs.getString("menu_name");
				String comment = rs.getString("comment");
				str = str + menu_name +":"+ comment + "&&&";
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return str;
	}
	

	/**
	 * ɾ��һ����������
	 */
	public boolean deleteOneComment(String menu_name,String comment) {
		
		String sql="delete from comments  where menu_name='"+menu_name+"' and comment='"+comment+"'";
		int n=-1;
		try {
			n=dbUtil.addDataToTable(sql);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n>0?true:false;
	}
	
	/**
	 * ����ͼ��idɾ��ͼ��
	 */
	public boolean deleteCommentByid(String id) {
		String sql="delete from comments where id='"+id+"'";
		int n=-1;
		try {
			n=dbUtil.addDataToTable(sql);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n>0?true:false;
	}
	
}
