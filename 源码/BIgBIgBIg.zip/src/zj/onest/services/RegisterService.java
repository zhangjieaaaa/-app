package zj.onest.services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import zj.onest.entitys.User;
import zj.onest.util.DBUtil;

public class RegisterService {
	private List<User> users;
	private DBUtil dbUtil;

	public RegisterService() {
		users = new ArrayList<User>();
		try {
			dbUtil = DBUtil.getInstance();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	/**
	 * ��ȡ�����û���Ϣ
	 * @param sql ��ѯͼ���sql���
	 * @return �û�����
	 */
	public List<User> getUsers(String sql){
		try {
			//��ѯ�����û���Ϣ
			ResultSet rs = dbUtil.queryDate(sql);
			while(rs.next()) {
				String user0 = rs.getString("phone_number");
				String password0 = rs.getString("password");
				String name0 = rs.getString("name");
				String img= rs.getString("img");
				String sex0= rs.getString("sex");
				int chuan= Integer.parseInt(rs.getString("hobby_chuan"));
				int lu= Integer.parseInt(rs.getString("hobby_lu"));
				int yu= Integer.parseInt(rs.getString("hobby_yu"));
				User user = createUser(user0, password0, name0, img, sex0,chuan,lu,yu);
				users.add(user);
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return users;
	}
	
	
	/**
	 * �����û���Ϣ�����û�����
	 */
	private User createUser(String phone_number, String password, String name, String img, String sex, int hobby_chuan,
			int hobby_lu, int hobby_yu) {
		User user = new User();
		user.setPhone_number(phone_number);
		user.setPassword(password);
		user.setName(name);
		user.setImg(img);
		user.setSex(sex);
		user.setHobby_chuan(hobby_chuan);
		user.setHobby_lu(hobby_lu);
		user.setHobby_yu(hobby_yu);	
		return user;
	}

	
	/**
	 * �ж��û��Ƿ����
	 * @param user ���жϵ��û�
	 * @return �����򷵻�true�����򷵻�false
	 */
	public boolean isExistUser(String user,String password) {
		//��ȡ���жϵ��û���Ϣ
		//�����û���Ϣƴ��sql���
		String sql = "select * from person_information where phone_number = '" + user +"' and password = '" + password +"'";
		System.out.println(sql);
		boolean b = false;
		try {
			b = dbUtil.isExist(sql);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return b;
	}
	/**
	 * ע���û�
	 * @param user ��ע����û�
	 * @return ע���Ƿ�ɹ����ɹ�����true�����򷵻�false
	 */
	public boolean regestUser(String user,String password,String name,String sex,String chuan,String lu,String yu) {
		
		System.out.println("����"+user+password+name+sex);
		String sql = "INSERT INTO person_information VALUES"
				+ "('"+user+"', '"+password+"', '"+name+"','img.png','"+sex+"',"+Integer.parseInt(chuan)+","+Integer.parseInt(lu)+","+Integer.parseInt(yu)+");";
				//���û�����Ϣ�����û�����
		int n = -1;//�洢����ļ�¼��
		try {
			n = dbUtil.addDataToTable(sql);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return n > 0 ? true : false;	
	}
	
	/**
	 * ��ѯ�û���Ϣ
	 * @param user ��ע����û�
	 * @return ע���Ƿ�ɹ����ɹ�����true�����򷵻�false
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public String searchUser(String user,String password) throws ClassNotFoundException, SQLException {//�����ַ�����Ϣ�û�����
	
		String sql = "select * from person_information where phone_number = '"+user+"' and password = '"+password+"'";
	
		ResultSet rs = dbUtil.queryDate(sql);
		
		String str=null;
		
		while(rs.next()) {

			String user0 = rs.getString("phone_number");
			String password0 = rs.getString("password");
			String name0 = rs.getString("name");
			String sex0= rs.getString("sex");
			String chuan= rs.getString("hobby_chuan");
			String lu= rs.getString("hobby_lu");
			String yu= rs.getString("hobby_yu");
			
			String img= rs.getString("img");
			
			str = user0 +"&&&"+ password0 +"&&&"+ name0 +"&&&"+ sex0 + "&&&"+ chuan + "&&&"+ lu + "&&&" + yu + "&&&" + img;
		}
		
		return str;
		
	}
	
	public String searchUserByuser(String user) throws ClassNotFoundException, SQLException {//�����ǳ�
		
		String sql = "select * from person_information where phone_number = '"+user+"'";
	
		ResultSet rs = dbUtil.queryDate(sql);
		String str=null;
		while(rs.next()) {
			String name0 = rs.getString("name");
			str = name0;
		}
		
		return str;
		
	}
	
	/**
	 * �����ֻ����޸�ָ���û���Ϣ
	 * @param  �ֻ���
	 */
	public boolean alterinformationByNumber(String user,String password,String name,String sex,String chuan,String lu,String yu) {
		String sql="UPDATE person_information SET phone_number = '"+user+"', password = '"+password+"', name = '"+name+"', sex = '"+sex+"', hobby_chuan = '"+Integer.parseInt(chuan)+"', hobby_lu = '"+Integer.parseInt(lu)+"', hobby_yu = '"+Integer.parseInt(yu)+"' WHERE phone_number = '"+user+"';";

		int n=-1;
		try {
			n=dbUtil.updateData(sql);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n>0?true:false;
	}
	/**
	 * �����ֻ����޸�ָ���û�ͷ��
	 * @param  �ֻ���
	 */
	public boolean alterinformationByNumber(String user,String img) {
		String sql="UPDATE person_information SET img = '"+img+"' WHERE phone_number = '"+user+"';";

		int n=-1;
		try {
			n=dbUtil.updateData(sql);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n>0?true:false;
	}
	
	/**
	 * �����û�����ɾ��ָ���û�
	 * @return �Ƿ�ɾ���û����ɹ�ɾ������true�����򷵻�false
	 */
	public boolean deleteUserByPhone_number(String Phone_number) {
		String sql="delete from person_information where Phone_number='"+Phone_number+"'";
		int n=-1;
		try {
			n=dbUtil.addDataToTable(sql);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n>0?true:false;
	}

}
