package zi.onest.administrators;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AlterMenuServletHtml
 */
@WebServlet("/AlterMenuServletHtml")
public class AlterMenuServletHtml extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AlterMenuServletHtml() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ���ñ��뷽ʽ
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		//��ȡͼ�����ƶ���
		String id=request.getParameter("id");
		
		PrintWriter writer = response.getWriter();
		writer.write("Ҫ�޸ĵĲ���idΪ�� " + id);
		
		writer.write("<form action='AlterMenuServlet?id="+id+"' method='post'>");
		
		writer.write("<p>�޸ĺ�Ĳ�����ϢΪ��</p> " + 
		"����                                    : <input type='text' name='name'><br/><br/>"+
		"���ࣨ��or³orԥ��      :  <input type='text' name='type'><br/><br/>"+
		"չʾͼƬ��(����img1) : <input type='text' name='img'><br/><br/>"+
		"չʾͼƬ��Դ                    : <input type='file' name='upFile'><br/><br/>"+
		"ԭ����                               :  <input type='text' name='material'><br/><br/>"+
		"��������                           : <input type='text' name='steps'><br/><br/>");
		
		writer.write("<input type='submit' value='�ύ'>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
