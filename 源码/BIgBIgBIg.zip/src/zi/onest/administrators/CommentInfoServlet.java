package zi.onest.administrators;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zj.onest.entitys.Comments;
import zj.onest.entitys.Menu;
import zj.onest.services.MenuService;

/**
 * Servlet implementation class CommentInfoServlet
 */
@WebServlet("/CommentInfoServlet")
public class CommentInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CommentInfoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ���ñ��뷽ʽ
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		// ��ȡPrintWriter����
		PrintWriter writer = response.getWriter();
		// ����û��Ƿ��Ѿ���¼
		ServletContext context = getServletContext();
		Object administrator = context.getAttribute("administrator");

		if (null == administrator) {// ��δ��¼
			writer.write("����δ��¼��<a href='login.html'>������µ�¼</a>");
		}else {
			// ��ȡ������Ϣ
			MenuService menuService = new MenuService();
			
			List<Comments> comments = menuService.getComments("select * from comments ");
			// �Ա�����ʽ���û���Ϣ���ظ��ͻ��������
			// ��ӡ�����ͷ
			writer.write("<table border='1'>");
			writer.write("<tr align='center'>");
			writer.write("<th width='100'>id</th>");
			writer.write("<th width='120'>���۵��ֻ�����</th>");
			writer.write("<th width='100'>����</th>");
			writer.write("<th width='100'>��������</th>");

			writer.write("<th width='100'>����</th>");
			writer.write("<th width='100'>����</th>");
			writer.write("</tr>");
			// ��ӡ��Ϣ
			for (Comments comment : comments) {
				writer.write("<tr align='center'>");
				// id
				writer.write("<td>");
				writer.write(comment.getId()+"");
				writer.write("</td>");
				// ���۵��ֻ�����
				writer.write("<td>");
				writer.write(comment.getPhone_number());
				writer.write("</td>");
				// ����
				writer.write("<td>");
				writer.write(comment.getMenu_name());
				writer.write("</td>");
				// ��������
				writer.write("<td>");
				writer.write(comment.getComment());
				writer.write("</td>");
	
				//ɾ��
				writer.write("<td>");
				writer.write("<a href='DeleteCommentServlet?id="+comment.getId()+"'>ɾ��</a>");
				writer.write("</td>");
				
				//�޸�
				writer.write("<td>");
				writer.write("<a href='#'>���</a>");
				writer.write("</td>");
				writer.write("</tr>");
			}
			writer.write("</table>");
			writer.write("<br/><br/>");

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
