package zi.onest.administrators;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zj.onest.entitys.Likes;
import zj.onest.entitys.Menu;
import zj.onest.services.MenuService;

/**
 * Servlet implementation class OneLikeServlet
 */
@WebServlet("/OneLikeServlet")
public class OneLikeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OneLikeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ���ñ��뷽ʽ
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		// ��ȡ�������
		String name = request.getParameter("name");
		// ��ȡPrintWriter����
		PrintWriter writer = response.getWriter();
		// ����û��Ƿ��Ѿ���¼
		ServletContext context = getServletContext();
		Object administrator = context.getAttribute("administrator");

		if (null == administrator) {// ��δ��¼
			writer.write("����δ��¼��<a href='login.html'>������µ�¼</a>");
		}else {
			// ��ȡ������Ϣ
			MenuService menuService = new MenuService();
			
			List<Likes> likes = menuService.getLikesHtml("select * from likes where menu_name = '"+name+"'");
			// �Ա�����ʽ���û���Ϣ���ظ��ͻ��������
			// ��ӡ�����ͷ
			writer.write("<table border='1'>");
			writer.write("<tr align='center'>");
			writer.write("<th width='100'>����id��</th>");
			writer.write("<th width='100'>����</th>");
			writer.write("<th width='100'>�����ֻ���</th>");
	
			writer.write("</tr>");
			// ��ӡ��Ϣ
			for (Likes like : likes) {
				writer.write("<tr align='center'>");
				// ����id��
				writer.write("<td>");
				writer.write(like.getId()+"");
				writer.write("</td>");
				// ����
				writer.write("<td>");
				writer.write(like.getMenu_name()+"");
				writer.write("</td>");
				// �����ֻ���
				writer.write("<td>");
				writer.write(like.getPhone_number()+"");
				writer.write("</td>");
	
			}
			writer.write("</table>");
			writer.write("<br/><br/>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
