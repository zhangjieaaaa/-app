package zi.onest.administrators;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zj.onest.entitys.Menu;
import zj.onest.services.MenuService;

/**
 * Servlet implementation class AddMenuServlet
 */
@WebServlet("/AddMenuServlet")
public class AddMenuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddMenuServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// ���ñ��뷽ʽ
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String img=request.getParameter("img");
		//����ͼƬ����ʾ��ҳ���ϣ���������վ��Ŀ¼��
		//��ȡ������
		String fileName = request.getParameter("upFile");
		System.out.println(fileName);
		InputStream in = new FileInputStream(fileName);

		//��ȡ��ǰվ���Ŀ¼
		String webDir = this.getServletContext().getRealPath("/");
		OutputStream fOut = new FileOutputStream(webDir+"imgs/"+img+".jpg");
		//ѭ����д
		int n = -1;
		while((n = in.read())!= -1) {
			fOut.write(n);
			fOut.flush();
		}
		//�ر���
		in.close();
		fOut.close();
		

		String name=request.getParameter("name");
		String type=request.getParameter("type");
		
		
		
		String material=request.getParameter("material");
		String steps=request.getParameter("steps");
		
		// ���������ӵ����ݿ�
		Menu menu = new Menu();
		menu.setName(name);
		menu.setType(type);
		menu.setImg(img);
		menu.setMaterial(material);
		menu.setSteps(steps);
		
		boolean flag = new MenuService().addMenu(menu);
		if(flag) {
			response.sendRedirect("MenuInfoServlet");
		}else {
			response.getWriter().write("��������ʧ��");
		}
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
