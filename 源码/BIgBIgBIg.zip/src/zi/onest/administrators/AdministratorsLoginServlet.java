package zi.onest.administrators;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zj.onest.entitys.Administrator;
import zj.onest.services.AdministratorService;




/**
 * Servlet implementation class AdministratorsLoginServlet
 */
@WebServlet("/AdministratorsLoginServlet")
public class AdministratorsLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdministratorsLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ���ñ��뷽ʽ
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html,charset=utf-8");
		// ��ȡ�������
		String uName = request.getParameter("uName");
		String uPwd = request.getParameter("uPwd");

		if (null != uName && null != uPwd) {
			// ���������������User����
			Administrator administrator = new Administrator();
			administrator.setuName(uName);
			administrator.setuPwd(uPwd);

			// ���÷����ӿڲ�ѯ�û��Ƿ����
			boolean b = new AdministratorService().isExistUser(administrator);
			if (b) {// ������ڸ��û�������ת����ҳ
				// ���û�����ServletContext
				getServletContext().setAttribute("administrator", administrator);

				response.sendRedirect("UserInfoServlet");
							
			} else {
				response.sendRedirect("loginfalse.html");
			}
		}
			

	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
