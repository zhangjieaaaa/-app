package zi.onest.administrators;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zj.onest.entitys.User;
import zj.onest.services.RegisterService;

/**
 * Servlet implementation class OneUserServlet
 */
@WebServlet("/OneUserServlet")
public class OneUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OneUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ��ȡ�������
		String user0 = request.getParameter("uName");
		String password = request.getParameter("uPwd");	
		// ���ñ��뷽ʽ
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		// ��ȡPrintWriter����
		PrintWriter writer = response.getWriter();
		// ����û��Ƿ��Ѿ���¼
		ServletContext context = getServletContext();
		Object administrator = context.getAttribute("administrator");

		if (null == administrator) {// ��δ��¼
			writer.write("����δ��¼��<a href='login.html'>������µ�¼</a>");
		}else {
			// ��ȡ�û���Ϣ
			RegisterService registerService = new RegisterService();
			
			List<User> users = registerService.getUsers("select * from person_information where phone_number = '"+user0+"' and password = '"+password+"'");
			System.out.println("select * from person_information where phone_number = '"+user0+"' and password = '"+password+"'");
			// �Ա�����ʽ���û���Ϣ���ظ��ͻ��������
			// ��ӡ�����ͷ
			writer.write("<table border='1'>");
			writer.write("<tr align='center'>");
			writer.write("<th width='100'>�û��ֻ���</th>");
			writer.write("<th width='100'>�û�����</th>");
			writer.write("<th width='100'>�ǳ�</th>");
			writer.write("<th width='100'>ͷ��</th>");
			writer.write("<th width='100'>�Ա�</th>");
			writer.write("<th width='100'>�Ƿ񰮺ô���</th>");
			writer.write("<th width='100'>�Ƿ񰮺�³��</th>");
			writer.write("<th width='100'>�Ƿ񰮺�³ԥ��</th>");
		
			writer.write("</tr>");
			// ��ӡͼ����Ϣ
			for (User user : users) {
				writer.write("<tr align='center'>");
				// �û��ֻ���
				writer.write("<td>");
				writer.write(new String((user.getPhone_number() + "").getBytes(), "utf-8"));
				writer.write("</td>");
				// ��ӡ�û�����
				writer.write("<td>");
				writer.write(user.getPassword());
				writer.write("</td>");
				// ��ӡ�ǳ�
				writer.write("<td>");
				writer.write(user.getName() + "");
				writer.write("</td>");
				// ��ӡͷ��
				writer.write("<td>");
				writer.write(user.getImg());
				writer.write("</td>");
				// ��ӡ�Ա�
				writer.write("<td>");
				writer.write(user.getSex());
				writer.write("</td>");
				// ��ӡ�Ƿ񰮺ô���
				writer.write("<td>");
				writer.write(user.getHobby_chuan()+"");
				writer.write("</td>");
				// ��ӡ�Ƿ񰮺�³��
				writer.write("<td>");
				writer.write(user.getHobby_lu()+"");
				writer.write("</td>");
				// ��ӡ�Ƿ񰮺�ԥ��
				writer.write("<td>");
				writer.write(user.getHobby_yu()+"");
				writer.write("</td>");
			
				writer.write("</tr>");
			}
			writer.write("</table>");
			writer.write("<br/><br/>");
	
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
